$(function() {
// your jquery goes here






// do not remove this line. Put your code above here.
});